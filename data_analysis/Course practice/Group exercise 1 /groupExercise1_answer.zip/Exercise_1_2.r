# Group Exercise 1 Q2

# Please load the given Titanic dataset ("Titanic.csv"). Consider the following data analytics questions.
library(dplyr)
titanic = read.csv('./R/巨量/answer/dataset/Titanic.csv', fill = T)

# 2.1 [5 pts]
# Please convert the categorical variables into factors.
categorical_features <- c("PassengerId", "Survived", "Pclass", "Name", "Sex", "Ticket", "Embarked")
titanic[categorical_features] <- lapply(titanic[categorical_features], as.factor)

# 2.2 [10 pts]
# Calculate the number of NA values in each column with any “apply” functions in R or Python, and remove those records (rows) with NA values.
sapply(titanic,function(x) sum(ifelse(is.na(x),1,0))) #return a vector
# Or
lapply(titanic,function(x) sum(ifelse(is.na(x),1,0))) #return a list 
# Or
apply(titanic,2,function(x) sum(ifelse(is.na(x),1,0))) #return a vector

titanic_naclear = titanic[rowSums(is.na(titanic)) == 0,]
# Or
titanic_naclear = na.omit(titanic)

# 2.3 [5 pts]
# Calculate the average fare (‘Fare’) among the different classes (‘Pclass’). Please sort the average fare in ascending order and show the result.
titanic_naclear %>%
  group_by(Pclass) %>%
  summarise(meanFare=mean(Fare)) %>% 
  arrange(meanFare)
# Or SQL
sqldf::sqldf("select Pclass, AVG(Fare) as meanFare from titanic_naclear group by Pclass order by meanFare asc")

# 2.4 [10 pts]
# Calculate the correlation matrix between numeric features. 
# Which two features have the strongest positive correlation? 
# And which two have the strongest negative correlation? 
# Please explain your answer.
numeric_cols <- sapply(titanic_naclear, is.numeric)
cor_matrix <- cor(titanic_naclear[, numeric_cols])
print(cor_matrix)
# In summary, based on this matrix, the two features with the strongest positive correlation are 'SibSp' and 'Parch', 
# while the two with the strongest negative correlation are 'Age' and 'SibSp'.   
# However, the negative correlation between 'Age' and 'SibSp' is not strong and might not be of significant importance when predicting one variable from the other.