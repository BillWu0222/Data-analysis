library(ggplot2); library(readr); library(dplyr)

# set your working directory
setwd('/home/ywwang/1121_bigData/')

# load three datasets
## data to be merged
car_merge_a = read_csv('./Car_Merge_A.csv')
car_merge_b = read_csv('./Car_Merge_B.csv')
## data to be concatenated 
car_concat = read_csv('./Car_Concat.csv')

# 1.1. Perform an inner join on the "Car_Merge_A'' and "Car_Merge_B" datasets 
# using "car_ID" as the primary key. Then, concatenate the merged dataset
# with the "Car_Concat" dataset along the row axis. 
# Convert any character columns in the final concatenated dataset to factor columns. 
# Note that the remaining 'car_ID' is not one of our variables, 
# delete it or convert it into the index.

## merge(inner join)
car_merged = merge(car_merge_a, car_merge_b, by='car_ID', all=FALSE)
## concatenate
car = bind_rows(car_merged, car_concat)
## convert character to factor
car$drivewheel = as.factor(car$drivewheel)
## replace the index with ID, and delete the ID column
rownames(car) = car$car_ID
car = car[, -1, drop=TRUE]; car
  
# 1.2. For continuous variables, 
# create density plots to understand the distribution of the data. 
# For categorical/factor variables, 
# generate frequency tables and bar charts to summarize the counts of each category.

## draw bar plot for factor variable, 
## density plot for numeric variable
lapply(colnames(car), function(x){
  if(is.factor(car[, x])){
    print(x); print(table(car[, x])) 
    ggplot(car, aes(x=car[, x])) + geom_bar(fill = "blue") + xlab(x)
    }else{
      ggplot(car, aes(x=car[, x])) + geom_density(color="darkblue", fill="lightblue") + xlab(x)
      }
  })

# 1.3. Consider doing a series of bivariate analyses on 
# "PRICE vs. the rest of variables". Specifically, plot your data and
# perform bivariate statistical tests to understand the relationships among the variables.

## store all variables
car_var = setdiff(colnames(car), "PRICE")
lapply(car_var, function(x){
  ## Simple linear model
  lm_xy = lm(eval(parse(text = paste("PRICE ~", x))), data=car)
  
  if(is.factor(car[, x])){
    ## box plot for factor
    print(ggplot(data=car, aes(x=car[, x], y=car[, "PRICE"])) + geom_boxplot() + labs(x=x, y="PRICE"))
    print(car::Anova(lm_xy, type=3))
  }else{
    ## scatter for numeric
    print(ggplot(data=car, aes(x=car[, x], y=car[, "PRICE"])) + geom_point() + labs(x=x, y="PRICE"))
    print(summary(lm_xy))
    }
  })

# 1.4. Please perform normality tests on PRICE. Does it seem "normal"? If not, 
# do you think fitting general linear models to predict or explain the outcome is appropriate?

## normality test
nortest::lillie.test(car$PRICE) # p-value = 8.092e-13
nortest::ad.test(car$PRICE) # p-value < 2.2e-16
# No, it seems not normal. General linear model may not be appropriate.

# 1.5. Consider fitting linear models with manually selected variables 
# (i.e., multivariate analysis). What is your best model? 
# You may consider those variables with "p < 0.05".

# Seems like the following model with the predictors is ok, based on "p < 0.05"
summary(lm(PRICE ~ ., data=car))
summary(lm(PRICE ~ wheelbase + enginesize + boreratio + stroke + horsepower + peakrpm, data=car))

# 1.6. Split the Car dataset into 70% training and 30% testing sets 
# using random seed “20230929”. Using the training set, 
# build multiple linear regression models with the 
# predictor variables selected in previous analyses.

## train test split(7:3)
set.seed(20230929)
train_idx = sample(1:nrow(car), 0.7 * nrow(car))
train_d = car[train_idx,]
test_d = car[setdiff(1:nrow(car), train_idx),]

# Build linear models with training set train_d. 
# You may consider reusing your selected variables in previous questions.

# Model with selected variables.
car_lm_select = lm(PRICE ~ wheelbase + enginesize + boreratio + stroke + horsepower + peakrpm, train_d)
# Model with all variables
car_lm_all = lm(PRICE ~ ., train_d) 
# Model with all variables with 2-way interactions
car_lm_all2way = lm(PRICE ~ (.)^2, train_d)

# 1.7. Write a function that compute Root Mean Square Error (RMSE). 
RMSE = function(pred, target){
  return(sqrt(mean((pred - target)^2)))
}

# Then apply your linear models to the training and testing set, train_d and test_d. 
# What are the RMSEs of your models? What is your best model in terms of accuracy of prediction (lowest RMSE)?

# Model with selected variables.
pred = car_lm_select$fitted.values
print(RMSE(pred, train_d$PRICE)) # 2305.927
pred = predict(car_lm_select, test_d)
print(RMSE(pred, test_d$PRICE)) # 1744.535

# Model with all variables
pred = car_lm_all$fitted.values
print(RMSE(pred, train_d$PRICE)) # 2251.896
pred = predict(car_lm_all, test_d)
print(RMSE(pred, test_d$PRICE)) # 1876.706

# Model with all variables with 2-way interactions, 
pred = car_lm_all2way$fitted.values
print(RMSE(pred, train_d$PRICE)) # 946.6921
pred = predict(car_lm_all2way, test_d)
print(RMSE(pred, test_d$PRICE)) # 10361.03

# 1.8. Run summary() to get more information about your linear models, and report 
# the variables with p-value < 0.05. Also run any correlation tests and report the 
# variables with high correlations. Do you think the correlation coefficient is 
# a good measurement for variable importance ranking?
summary(car_lm_all)

# Continuous predictors of the car data
car_cont_cols = setdiff(colnames(car)[sapply(car, function(x) !is.factor(x))], "PRICE")

Map(function(x){
  if(x != "PRICE"){
    print(x)
    print(cor.test(car[, x], car$PRICE, method="pearson"))
  }
},  car_cont_cols)